package com.example.taskapi.Util;

public class ValidationUtil {

    public static void validateLong(Long value, String fieldName) {

        if (value == null) {
            throw new RuntimeException(fieldName + " cannot be null");
        }

        if (value <= 0) {
            throw new RuntimeException(fieldName + " must be greater than 0");
        }
    }

}