package com.example.taskapi.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
@Builder
public class ApiResponseDTO<T> {

    @JsonProperty("status")
    private boolean success;
    private String message;
    private T data;
    private Instant timestamp;
}