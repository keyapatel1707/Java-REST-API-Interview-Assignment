package com.example.taskapi.Repository;

import com.example.taskapi.entity.TblAppUser;
import org.springframework.data.repository.CrudRepository;
import java.util.Optional;

public interface UserAuthRepository extends CrudRepository<TblAppUser, Long> {

    Optional<TblAppUser> findByEmail(String email);

    boolean existsByEmail(String email);
}