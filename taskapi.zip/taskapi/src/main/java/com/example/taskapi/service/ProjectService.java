package com.example.taskapi.service;

import com.example.taskapi.Repository.ProjectRepository;
import com.example.taskapi.Repository.UserRepository;
import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.ProjectDTO;
import com.example.taskapi.entity.TblAppUser;
import com.example.taskapi.entity.TblProject;
import com.example.taskapi.enums.ProjectStatus;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.example.taskapi.Util.ValidationUtil.validateLong;

@Service
@RequiredArgsConstructor
public class ProjectService {

    private final UserRepository userRepository;
    private final ProjectRepository projectRepository;

    @Transactional
    public ApiResponseDTO<?> addProject(ProjectDTO dto) {

        TblProject tblProject;

        if (dto.getProjectId() != null && dto.getProjectId() > 0) {

            tblProject = projectRepository.findById(dto.getProjectId())
                    .orElseThrow(() -> new RuntimeException("Project not found"));

        } else {
            tblProject = new TblProject();
            tblProject.setStatus(ProjectStatus.ACTIVE); // default for new
        }

        TblAppUser owner = userRepository.findById(dto.getOwnerUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        tblProject.setName(dto.getName());
        tblProject.setDescription(dto.getDescription());
        tblProject.setOwner(owner);

        if (dto.getStatus() != null && !dto.getStatus().isEmpty()) {
            try {
                tblProject.setStatus(ProjectStatus.valueOf(dto.getStatus().toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new RuntimeException("Invalid status value. Allowed: ACTIVE, INACTIVE, ARCHIVED");
            }
        }

        TblProject saved = projectRepository.save(tblProject);

        Map<String, Object> responseData = new HashMap<>();
        responseData.put("id", saved.getId());
        responseData.put("name", saved.getName());
        responseData.put("description", saved.getDescription());
        responseData.put("status", saved.getStatus());
        responseData.put("ownerUserId", owner.getId());
        responseData.put("createdAt", saved.getCreatedAt());

        if (dto.getProjectId() != null && dto.getProjectId() > 0) {
            responseData.put("updatedAt", saved.getUpdatedAt());
        }

        return ApiResponseDTO.builder()
                .success(true)
                .message("Project saved successfully")
                .data(responseData)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> getAllProject() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        List<TblProject> users = (List<TblProject>) projectRepository.findAll();

        List<ProjectDTO> projectDTOList = users.stream()
                .map(project -> ProjectDTO.builder()
                        .projectId(project.getId())
                        .name(project.getName())
                        .description(project.getDescription())
                        .ownerUserId(project.getOwner() != null ? project.getOwner().getId() : null)
                        .status(project.getStatus() != null ? project.getStatus().name() : null)
                        .date(project.getCreatedAt())
                        .build())
                .collect(Collectors.toList());

        return ApiResponseDTO.builder()
                .success(true)
                .message(" All Project fetched successfully")
                .data(projectDTOList)
                .timestamp(Instant.now())
                .build();
    }

    @Transactional
    public ApiResponseDTO<?> getAllProjectById(Long projectID) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        validateLong(projectID, "User Id");

        List<Object[]> results = projectRepository.getAllProjectsByUserId(projectID);
        List<ProjectDTO> dtoList = new ArrayList<>();
        for (Object[] obj : results) {

            ProjectDTO dto = new ProjectDTO();
            dto.setProjectId((Long) obj[0]);
            dto.setName((String) obj[1]);
            dto.setDescription((String) obj[2]);
            dtoList.add(dto);
        }

        return ApiResponseDTO.builder()
                .success(true)
                .message("Success")
                .data(dtoList)
                .timestamp(Instant.now())
                .build();
    }
    @Transactional
    public ApiResponseDTO<?> deleteProjectById(Long projectId) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        validateLong(projectId, "Project Id");

        projectRepository.deleteProjectById(ProjectStatus.INACTIVE, projectId);

        return ApiResponseDTO.builder()
                .success(true)
                .message("Success")
                .data(projectId)
                .timestamp(Instant.now())
                .build();
    }
}