package com.example.taskapi.security;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Task API")
                        .version("1.0")
                        .description("Swagger setup working"))

                .addTagsItem(new Tag().name("TaskController").description("APIs related to Tasks"))
                .addTagsItem(new Tag().name("UserController").description("APIs related to Users"))
                .addTagsItem(new Tag().name("ProjectController").description("APIs related to Projects"))
                .addTagsItem(new Tag().name("UserAuthControler").description("APIs related to User"));

    }
}