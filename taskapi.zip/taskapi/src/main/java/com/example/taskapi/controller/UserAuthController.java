package com.example.taskapi.controller;

import com.example.taskapi.dto.UserAuthDTO;
import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.service.UserAuthService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class UserAuthController {

    private final UserAuthService userAuthService;

    @PostMapping("/register")
    public ApiResponseDTO register(@RequestBody UserAuthDTO dto) {
        return userAuthService.register(dto);
    }
    @PostMapping("/login")
    public ApiResponseDTO login(@RequestBody UserAuthDTO dto,
                                HttpServletRequest request) {

        String ipAddress = request.getRemoteAddr();
        String userAgent = request.getHeader("User-Agent");

        return userAuthService.login(dto, ipAddress, userAgent);
    }


    }