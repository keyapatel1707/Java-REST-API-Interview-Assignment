package com.example.taskapi.controller;

import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.ProjectDTO;
import com.example.taskapi.dto.UserAuthDTO;
import com.example.taskapi.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/projects")
@RequiredArgsConstructor

public class ProjectController {

    private final ProjectService projectService;

    @PostMapping ("/add-project")
    public ResponseEntity<ApiResponseDTO<?>> addProject(@RequestBody ProjectDTO dto) {
        ApiResponseDTO<?> response = projectService.addProject(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/get-project")
    public ApiResponseDTO<?> getAllProject() {
        return projectService.getAllProject();
    }
    @PostMapping("/get-project-Id/{projectID}")
    public ApiResponseDTO<?> getAllProjectById(@PathVariable Long projectID) {
        return projectService.getAllProjectById(projectID);
    }

    @DeleteMapping("/delete-project-Id/{id}")
    public ApiResponseDTO<?> deleteProjectById(@PathVariable Long id) {
        return projectService.deleteProjectById(id);
    }

}
