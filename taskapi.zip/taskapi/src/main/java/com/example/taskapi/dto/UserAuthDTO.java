package com.example.taskapi.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Builder;
import java.time.Instant;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@Builder
public class UserAuthDTO {
    private Long userId;
    private String fullName;
    private String email;
    private String password;
    private String role;
    private LocalDateTime date;
    private Instant timestamp;
    private Boolean isActive;
    private String accessToken;

}
