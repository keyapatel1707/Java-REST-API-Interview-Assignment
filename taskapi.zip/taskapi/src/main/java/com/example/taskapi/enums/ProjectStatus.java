package com.example.taskapi.enums;

public enum ProjectStatus {
    ACTIVE,
    INACTIVE,
    ARCHIVED
}
