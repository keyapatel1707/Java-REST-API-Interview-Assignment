package com.example.taskapi.service;

import com.example.taskapi.Repository.UserRepository;
import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.UserAuthDTO;
import com.example.taskapi.entity.TblAppUser;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import static com.example.taskapi.Util.ValidationUtil.validateLong;

@RequiredArgsConstructor
@Service
public class UserService {

    private final UserRepository userRepository;

    public ApiResponseDTO<?> getUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        TblAppUser user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        UserAuthDTO userResponse = UserAuthDTO.builder()
                .userId(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole())
                .isActive(user.getIsActive())
                .build();

        return ApiResponseDTO.builder()
                .success(true)
                .message("User fetched successfully")
                .data(userResponse)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> getAllUsers() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        List<TblAppUser> users = (List<TblAppUser>) userRepository.findAll();

        List<UserAuthDTO> userList = users.stream()
                .map(user -> UserAuthDTO.builder()
                        .userId(user.getId())
                        .fullName(user.getFullName())
                        .email(user.getEmail())
                        .role(user.getRole())
                        .isActive(user.getIsActive())
                        .build())
                .collect(Collectors.toList());

        return ApiResponseDTO.builder()
                .success(true).message(" All Users fetched successfully")
                .data(userList)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> getAllUsersById(Long userId) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        validateLong(userId, "userId");

        Object[] obj = userRepository.getUserById(userId);


        UserAuthDTO dto = new UserAuthDTO();
        dto.setUserId((Long) obj[0]);
        dto.setFullName((String) obj[1]);
        dto.setEmail((String) obj[2]);
        dto.setRole((String) obj[3]);
        dto.setIsActive((Boolean) obj[4]);

        return ApiResponseDTO.builder()
                .success(true).message("Success")
                .data(dto)
                .timestamp(Instant.now())
                .build();
    }

    @Transactional
    public ApiResponseDTO<?> updateUserStatus(Long userId) {

        validateLong(userId, "userId");

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        TblAppUser user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setIsActive(!user.getIsActive());

        userRepository.saveAndFlush(user);

        return ApiResponseDTO.builder()
                .success(true).message("User status updated successfully")
                .data(user.getIsActive())
                .timestamp(Instant.now())
                .build();
    }
}