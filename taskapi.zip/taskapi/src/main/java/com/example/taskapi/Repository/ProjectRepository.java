package com.example.taskapi.Repository;

import com.example.taskapi.entity.TblProject;
import com.example.taskapi.enums.ProjectStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProjectRepository extends JpaRepository<TblProject, Long> {
    @Query("SELECT p.id, p.name, p.description FROM TblProject p WHERE p.owner.id = :userId")
    List<Object[]> getAllProjectsByUserId(Long userId);

    @Transactional
    @Modifying
    @Query("UPDATE TblProject p SET p.status = :status WHERE p.id = :id")
    void deleteProjectById(@Param("status") ProjectStatus status,
                           @Param("id") Long id);
}
