package com.example.taskapi.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    // Must be at least 32 characters for HS256
    private static final String SECRET = "smnviflhjwrjgklfmfuergporksdel4eaiugxjdvmcahstghorgnxvjamfDSl";

    private Key getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET.getBytes()); // ✅ FIX HERE
    }

    public String generateToken(String email) {

        return Jwts.builder()
                .setSubject(email)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3600000))
                .signWith(getSigningKey())
                .compact();
    }
    public String extractEmail(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

}