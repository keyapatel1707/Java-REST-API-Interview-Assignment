package com.example.taskapi.Repository;

import com.example.taskapi.entity.TblTask;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TaskRepository extends JpaRepository<TblTask, Long>, JpaSpecificationExecutor<TblTask> {

    @Query("SELECT t.project.id, t.title, t.description FROM TblTask t WHERE t.assignee.id = :userId")
    List<Object[]> getAllTaskByUserId(@Param("userId") Long userId);

    @Modifying
    @Transactional
    @Query("UPDATE TblTask t SET t.status = :status WHERE t.id = :id")
    int updateTaskStatus(@Param("status") String status, @Param("id") Long id);
}