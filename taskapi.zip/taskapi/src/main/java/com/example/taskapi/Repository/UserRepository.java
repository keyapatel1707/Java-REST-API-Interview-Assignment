package com.example.taskapi.Repository;

import com.example.taskapi.entity.TblAppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<TblAppUser, Long> {
    Optional<TblAppUser> findByEmail(String email);

    @Query("SELECT u.id, u.fullName, u.email, u.role, u.isActive FROM TblAppUser u WHERE u.id = :userId")
    Object[] getUserById(@Param("userId") Long userId);

}
