package com.example.taskapi.controller;

import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.TaskDTO;
import com.example.taskapi.service.TaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/task")
@RequiredArgsConstructor

public class TaskController {

    private final TaskService taskService;

    @PostMapping ("/add-task")

    public ResponseEntity<ApiResponseDTO<?>>addTask(@RequestBody TaskDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(taskService.addTask(dto));
    }

    @GetMapping("/get-task")
    public ApiResponseDTO<?> getAllTask() {
        return taskService.getAllTask();
    }

    @GetMapping("/get-task-Id/{id}")
    public ApiResponseDTO<?> getTaskById(@PathVariable("id") Long taskId) {
        return taskService.getTaskById(taskId);
    }

    @DeleteMapping("/delete-task-Id/{id}")
    public ApiResponseDTO<?> deleteTaskById(@PathVariable("id") Long TaskId) {
        return taskService.deleteTaskById(TaskId);
    }

    @GetMapping
    public ApiResponseDTO<?> getTasks(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String priority,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "2") int size
    ) {
        return taskService.getTasks(status, priority, page, size);
    }
}

