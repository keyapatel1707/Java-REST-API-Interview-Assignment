package com.example.taskapi.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class ProjectDTO {
    private Long projectId;
    private String name;
    private String description;
    private Long ownerUserId;
    private String status;
    private LocalDateTime date;

}
