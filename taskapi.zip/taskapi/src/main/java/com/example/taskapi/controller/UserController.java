package com.example.taskapi.controller;

import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.UserAuthDTO;
import com.example.taskapi.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor

public class UserController {
    private final UserService userService;

    @GetMapping("/me")
    public ApiResponseDTO<?> getUser() {
        return userService.getUser();
    }

    @GetMapping("/admin-user")
    public ApiResponseDTO<?> getAllUsers() {
        return userService.getAllUsers();
    }
    @PostMapping("/admin-user-Id/{id}")
    public ApiResponseDTO<?> getAllUsersById(@PathVariable Long id) {
        return userService.getAllUsersById(id);
    }

    @PatchMapping("/update-status/{id}")
    public ApiResponseDTO<?> updateUserStatus(@PathVariable Long id) {
        return userService.updateUserStatus(id);
    }
}
