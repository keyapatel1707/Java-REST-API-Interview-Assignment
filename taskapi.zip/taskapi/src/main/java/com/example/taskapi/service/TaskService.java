package com.example.taskapi.service;

import com.example.taskapi.Repository.ProjectRepository;
import com.example.taskapi.Repository.TaskRepository;
import com.example.taskapi.Repository.UserRepository;
import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.TaskDTO;
import com.example.taskapi.entity.TblAppUser;
import com.example.taskapi.entity.TblProject;
import com.example.taskapi.entity.TblTask;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jakarta.persistence.criteria.Predicate;
import java.util.stream.Collectors;

import static com.example.taskapi.Util.ValidationUtil.validateLong;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public ApiResponseDTO<?> addTask(TaskDTO dto) {

        if (dto.getAssigneeUserId() != null) validateLong(dto.getAssigneeUserId(), "Assignee User Id");
        if (dto.getProjectId() != null) validateLong(dto.getProjectId(), "Project Id");

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        TblAppUser currentUser = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        TblAppUser assignee = userRepository.findById(dto.getAssigneeUserId())
                .orElseThrow(() -> new RuntimeException("Assignee not found"));

        TblProject project = projectRepository.findById(dto.getProjectId())
                .orElseThrow(() -> new RuntimeException("Project not found"));

        TblTask task;

        if (dto.getId() != null) {
            task = taskRepository.findById(dto.getId())
                    .orElseThrow(() -> new RuntimeException("Task not found"));

            if (dto.getTitle() != null) task.setTitle(dto.getTitle());
            if (dto.getDescription() != null) task.setDescription(dto.getDescription());
            if (dto.getPriority() != null) task.setPriority(dto.getPriority());
            if (dto.getDueDate() != null) task.setDueDate(dto.getDueDate());
            if (dto.getAssigneeUserId() != null) task.setAssignee(assignee);
            if (dto.getProjectId() != null) task.setProject(project);
            if (dto.getStatus() != null) task.setStatus(dto.getStatus());

        } else {
            task = new TblTask();
            task.setTitle(dto.getTitle());
            task.setDescription(dto.getDescription());
            task.setStatus("OPEN");
            task.setPriority(dto.getPriority());
            task.setDueDate(dto.getDueDate());
            task.setAssignee(assignee);
            task.setProject(project);
            task.setCreatedBy(currentUser);
            task.setCreatedAt(LocalDateTime.now());
        }

        taskRepository.save(task);

        // Prepare response
        Map<String, Object> responseData = new HashMap<>();
        responseData.put("id", task.getId());
        responseData.put("title", task.getTitle());
        responseData.put("description", task.getDescription());
        responseData.put("status", task.getStatus());
        responseData.put("priority", task.getPriority());
        responseData.put("assigneeUserId", task.getAssignee().getId());
        responseData.put("projectId", task.getProject().getId());
        responseData.put("createdBy", task.getCreatedBy() != null ? task.getCreatedBy().getId() : null);
        responseData.put("dueDate", task.getDueDate());
        responseData.put("createdAt", task.getCreatedAt());
        responseData.put("updatedAt", LocalDateTime.now());

        return ApiResponseDTO.builder()
                .success(true)
                .message(dto.getId() != null ? "Task updated successfully" : "Task created successfully")
                .data(responseData)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> getAllTask() {

        List<TblTask> tasks = taskRepository.findAll();

        List<TaskDTO> taskDTOList = tasks.stream()
                .map(task -> TaskDTO.builder()
                        .projectId(task.getProject().getId())
                        .id(task.getId())
                        .title(task.getTitle())
                        .description(task.getDescription())
                        .status(task.getStatus())
                        .priority(task.getPriority())
                        .assigneeUserId(
                                task.getAssignee() != null ? task.getAssignee().getId() : null
                        )
                        .dueDate(task.getDueDate())
                        .build())
                .collect(Collectors.toList());

        return ApiResponseDTO.builder()
                .success(true)
                .message("All tasks fetched successfully")
                .data(taskDTOList)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> getTaskById(Long taskId) {
        validateLong(taskId, "Task Id");

        TblTask task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        TaskDTO dto = TaskDTO.builder()
                .projectId(task.getProject().getId())
                .id(task.getId())
                .title(task.getTitle())
                .description(task.getDescription())
                .status(task.getStatus())
                .priority(task.getPriority())
                .assigneeUserId(task.getAssignee().getId())
                .dueDate(task.getDueDate())
                .build();

        return ApiResponseDTO.builder()
                .success(true)
                .message("Task fetched successfully")
                .data(dto)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> deleteTaskById(Long TaskId) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        validateLong(TaskId, "Task Id");

        taskRepository.updateTaskStatus("INACTIVE", TaskId);
        return ApiResponseDTO.builder()
                .success(true)
                .message("Success")
                .data(TaskId)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO<?> getTasks(String status, String priority, int page, int size) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        TblAppUser user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Pageable pageable = PageRequest.of(page, size, Sort.by("dueDate").ascending());

        Specification<TblTask> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            predicates.add(cb.equal(root.get("assignee").get("id"), user.getId()));

            if (status != null) predicates.add(cb.equal(root.get("status"), status));
            if (priority != null) predicates.add(cb.equal(root.get("priority"), priority));

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        Page<TblTask> result = taskRepository.findAll(spec, pageable);

        Map<String, Object> data = new HashMap<>();
        data.put("content", result.getContent().stream().map(task -> {
            Map<String, Object> m = new HashMap<>();
            m.put("id", task.getId());
            m.put("title", task.getTitle());
            m.put("status", task.getStatus());
            m.put("priority", task.getPriority());
            m.put("projectId", task.getProject().getId());
            m.put("assigneeUserId", task.getAssignee().getId());
            m.put("dueDate", task.getDueDate());
            return m;
        }).toList());

        data.put("page", result.getNumber());
        data.put("size", result.getSize());
        data.put("totalElements", result.getTotalElements());
        data.put("totalPages", result.getTotalPages());
        data.put("sort", "dueDate,asc");

        return ApiResponseDTO.builder()
                .success(true)
                .message("Tasks fetched successfully")
                .data(data)
                .timestamp(Instant.now())
                .build();
    }
}