package com.example.taskapi.service;

import com.example.taskapi.dto.ApiResponseDTO;
import com.example.taskapi.dto.UserAuthDTO;
import com.example.taskapi.entity.TblAppUser;
import com.example.taskapi.Repository.UserAuthRepository;
import com.example.taskapi.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class UserAuthService {

    private final UserAuthRepository userAuthRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public ApiResponseDTO register(UserAuthDTO dto) {

        if (userAuthRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        TblAppUser user = new TblAppUser();
        user.setFullName(dto.getFullName());
        user.setEmail(dto.getEmail());
        user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
        user.setRole("USER");
        user.setIsActive(true);
        userAuthRepository.save(user);

        Map<String, Object> response = new HashMap<>();
        response.put("fullName", user.getFullName());
        response.put("email", user.getEmail());
        response.put("role", user.getRole());
        response.put("isActive", user.getIsActive());
        response.put("createdAt", user.getCreatedAt());

        return ApiResponseDTO.builder()
                .success(true)
                .message("User registered successfully")
                .data(response)
                .timestamp(Instant.now())
                .build();
    }

    public ApiResponseDTO login(UserAuthDTO dto, String ipAddress, String userAgent) {

              String email = dto.getEmail().trim().toLowerCase();

        TblAppUser user = userAuthRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

        if (!passwordEncoder.matches(dto.getPassword(), user.getPasswordHash())) {
            throw new RuntimeException("Invalid password");
        }

        String token = jwtUtil.generateToken(user.getEmail());

        Map<String, Object> userData = new HashMap<>();
        userData.put("id", user.getId());
        userData.put("fullName", user.getFullName());
        userData.put("email", user.getEmail());
        userData.put("role", user.getRole());

        Map<String, Object> responseData = new HashMap<>();
        responseData.put("tokenType", "Bearer");
        responseData.put("accessToken", token);
        responseData.put("expiresIn", 3600);
        responseData.put("user", userData);

        return new ApiResponseDTO(
                true,
                "Login successful",
                responseData,
                Instant.now()
        );
    }
}


